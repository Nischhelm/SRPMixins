planned:
	
	overseers destroy obsidian
	
	potion that disables coth
	potion that turns back assimilated mobs
	
code changes:
	bloodmoon in LC
	lures disabled in LC
	dimension stat multiplier on parasites (default 1 overworld, 2 nether+end, 4 LC)
	dimension drop chance multiplier on parasites
	disable LC portal until phase 6
	added nexus specific mob cap
	mostly fixed the weird phase reset on dimension change
	blacklist of nexus mobs that take dmg on rschance=0
	sleeping not giving more penalty with more players
	end simmerman balancing
		simmermen despawn in end
		cap enderman conversion in end to 40. if theres more loaded simmermen, coth killed endermen just die, dont convert
	fixed lyca spawner not working before reload
	gave carcasses phase dependent point multipliers
	player specific evolution phase
	
	
config
	assim enderdragon can spawn (default behavior: unlock when end at phase 3)
	preeminents can spawn (default behavior: only if colonies active)
	made stage 3+4 beckon+ stage 2-4 dispatcher spawn in phase 8+ at low weight
	inf dragons turn to simdrags with coth
	lots of phase spawn changes
	parasitic biome spawns less bad mobs, more hard mobs
	node distance decreased
	end starts at phase 3
	LC starts at phase 8
	added skyhighPara spawner (ada yelloweye and overseer) in lyca config to disincentivize sky bases
	unlock beckon (3), dispatcher (3,4) and preeminent spawns from phase 6 onwards after you entered LC in phase 9